import React, { useState } from 'react';
import { FileItem } from '../../types';
import { ChevronLeft, ChevronRight, ZoomIn, ZoomOut } from 'lucide-react';
import Button from '../UI/Button';

interface PDFViewerProps {
  file: FileItem;
}

// This is a placeholder component since we don't have a PDF rendering library
// In a real application, you would use react-pdf or similar library
const PDFViewer: React.FC<PDFViewerProps> = ({ file }) => {
  const [page, setPage] = useState(1);
  const [totalPages] = useState(10); // This would come from the PDF library
  const [zoom, setZoom] = useState(100);
  
  const handlePrevPage = () => {
    if (page > 1) {
      setPage(page - 1);
    }
  };
  
  const handleNextPage = () => {
    if (page < totalPages) {
      setPage(page + 1);
    }
  };
  
  const handleZoomIn = () => {
    setZoom(Math.min(zoom + 25, 200));
  };
  
  const handleZoomOut = () => {
    setZoom(Math.max(zoom - 25, 50));
  };
  
  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center justify-between border-b border-gray-200 p-3">
        <div className="flex items-center">
          <span className="text-sm text-gray-600">
            Page {page} of {totalPages}
          </span>
          <div className="ml-4 flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={handlePrevPage}
              disabled={page === 1}
              className="p-1"
            >
              <ChevronLeft size={18} />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleNextPage}
              disabled={page === totalPages}
              className="p-1"
            >
              <ChevronRight size={18} />
            </Button>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="sm" onClick={handleZoomOut} className="p-1">
            <ZoomOut size={18} />
          </Button>
          <span className="text-sm">{zoom}%</span>
          <Button variant="ghost" size="sm" onClick={handleZoomIn} className="p-1">
            <ZoomIn size={18} />
          </Button>
        </div>
      </div>
      
      <div className="flex-1 overflow-auto bg-gray-100 p-4">
        <div
          className="mx-auto bg-white shadow-lg"
          style={{
            width: `${8.5 * zoom / 100}in`,
            height: `${11 * zoom / 100}in`,
          }}
        >
          <div className="flex h-full items-center justify-center">
            <p className="text-gray-400">
              This is a placeholder for {file.name}. In a real application, the PDF content would be displayed here.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PDFViewer;