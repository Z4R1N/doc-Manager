import React from 'react';
import { FileItem } from '../../types';

interface DocxViewerProps {
  file: FileItem;
}

// This is a placeholder component
// In a real application, you would use a library to render DOCX files
const DocxViewer: React.FC<DocxViewerProps> = ({ file }) => {
  return (
    <div className="flex h-full items-center justify-center bg-gray-100 p-6">
      <div className="w-full max-w-4xl rounded-lg bg-white p-8 shadow-lg">
        <h1 className="mb-4 text-2xl font-bold">{file.name}</h1>
        <p className="text-gray-600">
          This is a placeholder for DOCX content. In a real application, the document content would be displayed here.
        </p>
      </div>
    </div>
  );
};

export default DocxViewer;