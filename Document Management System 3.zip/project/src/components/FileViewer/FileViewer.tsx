import React from 'react';
import { FileItem, FolderItem } from '../../types';
import { isFolder } from '../../utils/fileHelpers';
import PDFViewer from './PDFViewer';
import DocxViewer from './DocxViewer';
import { Folder, File } from 'lucide-react';

interface FileViewerProps {
  selectedItem: FileItem | FolderItem | null;
  breadcrumbs: { id: string; name: string }[];
  onBreadcrumbClick: (id: string) => void;
}

const FileViewer: React.FC<FileViewerProps> = ({
  selectedItem,
  breadcrumbs,
  onBreadcrumbClick,
}) => {
  if (!selectedItem) {
    return (
      <div className="flex h-full flex-col items-center justify-center bg-gray-50 p-8">
        <File size={64} className="mb-4 text-gray-300" />
        <h2 className="text-xl font-medium text-gray-500">
          Select a file to view
        </h2>
      </div>
    );
  }

  return (
    <div className="flex h-full flex-col">
      {/* Breadcrumb navigation */}
      <div className="flex items-center border-b border-gray-200 bg-white p-3">
        {breadcrumbs.map((crumb, index) => (
          <React.Fragment key={crumb.id}>
            {index > 0 && <span className="mx-2 text-gray-400">/</span>}
            <button
              className="text-sm hover:text-blue-500 focus:outline-none"
              onClick={() => onBreadcrumbClick(crumb.id)}
            >
              {crumb.name}
            </button>
          </React.Fragment>
        ))}
      </div>

      {/* Content area */}
      <div className="flex-1 overflow-auto">
        {isFolder(selectedItem) ? (
          <div className="p-6">
            <div className="mb-4 flex items-center">
              <Folder size={20} className="mr-2 text-blue-500" />
              <h2 className="text-xl font-medium">{selectedItem.name}</h2>
            </div>

            {selectedItem.items.length === 0 ? (
              <p className="text-gray-500">This folder is empty</p>
            ) : (
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
                {selectedItem.items.map((item) => (
                  <div
                    key={item.id}
                    className="flex flex-col items-center rounded-lg border border-gray-200 p-4 shadow-sm transition-all hover:shadow-md"
                  >
                    {isFolder(item) ? (
                      <Folder size={40} className="mb-2 text-blue-500" />
                    ) : (
                      <File size={40} className="mb-2 text-gray-500" />
                    )}
                    <span className="text-center text-sm font-medium">
                      {item.name}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : selectedItem.type === 'pdf' ? (
          <PDFViewer file={selectedItem} />
        ) : (
          <DocxViewer file={selectedItem} />
        )}
      </div>
    </div>
  );
};

export default FileViewer;