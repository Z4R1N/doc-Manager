import React from 'react';
import { Plus, FolderPlus, Upload } from 'lucide-react';
import { FilesystemItem } from '../../types';
import FolderItem from './FolderItem';
import Button from '../UI/Button';

interface SidebarProps {
  items: FilesystemItem[];
  selectedItemId: string | null;
  onSelect: (id: string) => void;
  onCreateRootFolder: () => void;
  onCreateFolder: (parentId: string) => void;
  onUploadFile: (parentId: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({
  items,
  selectedItemId,
  onSelect,
  onCreateRootFolder,
  onCreateFolder,
  onUploadFile,
}) => {
  return (
    <div className="flex h-full flex-col border-r border-gray-200 bg-gray-50">
      <div className="flex items-center justify-between border-b border-gray-200 p-4">
        <h2 className="text-lg font-medium">Files</h2>
        <Button
          variant="primary"
          size="sm"
          onClick={onCreateRootFolder}
          className="rounded-full p-1"
          title="Create folder"
        >
          <FolderPlus size={18} />
        </Button>
      </div>
      
      <div className="flex-1 overflow-y-auto p-2">
        {items.map((item) => (
          <FolderItem
            key={item.id}
            item={item}
            depth={0}
            selectedItemId={selectedItemId}
            onSelect={onSelect}
            onCreateFolder={onCreateFolder}
            onUploadFile={onUploadFile}
          />
        ))}
      </div>
    </div>
  );
};

export default Sidebar;