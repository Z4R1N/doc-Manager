import React, { useState } from 'react';
import { ChevronRight, ChevronDown, Folder, FileText, Plus, Upload } from 'lucide-react';
import { FolderItem as FolderItemType, FileItem, FilesystemItem } from '../../types';
import { isFolder } from '../../utils/fileHelpers';
import Button from '../UI/Button';

interface FolderItemProps {
  item: FilesystemItem;
  depth: number;
  selectedItemId: string | null;
  onSelect: (id: string) => void;
  onCreateFolder: (parentId: string) => void;
  onUploadFile: (parentId: string) => void;
}

const FolderItem: React.FC<FolderItemProps> = ({ 
  item, 
  depth, 
  selectedItemId, 
  onSelect, 
  onCreateFolder,
  onUploadFile
}) => {
  const [isExpanded, setIsExpanded] = useState(depth === 0);
  
  const handleToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isFolder(item)) {
      setIsExpanded(!isExpanded);
      onSelect(item.id);
    }
  };
  
  const handleSelect = () => {
    onSelect(item.id);
  };
  
  const handleCreateFolder = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isFolder(item)) {
      onCreateFolder(item.id);
    }
  };
  
  const handleUploadFile = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isFolder(item)) {
      onUploadFile(item.id);
    }
  };
  
  const isSelected = selectedItemId === item.id;
  const paddingLeft = `${depth * 12 + 8}px`;
  
  if (!isFolder(item)) {
    // Render file item
    const file = item as FileItem;
    return (
      <div 
        className={`flex cursor-pointer items-center py-1 px-2 ${
          isSelected ? 'bg-blue-100' : 'hover:bg-gray-100'
        }`}
        style={{ paddingLeft }}
        onClick={handleSelect}
      >
        <FileText size={16} className="mr-2 text-gray-500" />
        <span className="truncate text-sm">{file.name}</span>
      </div>
    );
  }
  
  // Render folder item
  const folder = item as FolderItemType;
  return (
    <div>
      <div 
        className={`group flex cursor-pointer items-center py-1 px-2 ${
          isSelected ? 'bg-blue-100' : 'hover:bg-gray-100'
        }`}
        style={{ paddingLeft }}
        onClick={handleToggle}
      >
        <button 
          className="mr-1 p-1 text-gray-500 hover:text-gray-700"
          onClick={handleToggle}
        >
          {isExpanded ? (
            <ChevronDown size={14} />
          ) : (
            <ChevronRight size={14} />
          )}
        </button>
        <Folder size={16} className="mr-2 text-blue-500" />
        <span className="flex-1 truncate text-sm">{folder.name}</span>
        
        {/* Folder actions */}
        <div className="ml-2 hidden items-center gap-1 group-hover:flex">
          <Button 
            variant="ghost" 
            size="sm"
            className="p-1"
            onClick={handleCreateFolder} 
            title="Create folder"
          >
            <Plus size={14} />
          </Button>
          <Button 
            variant="ghost" 
            size="sm"
            className="p-1"
            onClick={handleUploadFile} 
            title="Upload file"
          >
            <Upload size={14} />
          </Button>
        </div>
      </div>
      
      {/* Render children if expanded */}
      {isExpanded && (
        <div className="ml-2">
          {folder.items.map((childItem) => (
            <FolderItem
              key={childItem.id}
              item={childItem}
              depth={depth + 1}
              selectedItemId={selectedItemId}
              onSelect={onSelect}
              onCreateFolder={onCreateFolder}
              onUploadFile={onUploadFile}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default FolderItem;