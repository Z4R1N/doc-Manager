export interface FileItem {
  id: string;
  name: string;
  type: 'pdf' | 'docx';
  url: string;
  createdAt: Date;
}

export interface FolderItem {
  id: string;
  name: string;
  items: (FolderItem | FileItem)[];
  createdAt: Date;
  parentId: string | null;
}

export type FilesystemItem = FolderItem | FileItem;

export interface BreadcrumbItem {
  id: string;
  name: string;
}