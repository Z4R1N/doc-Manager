import { FileItem, FolderItem, FilesystemItem } from '../types';

export const isFolder = (item: FilesystemItem): item is FolderItem => {
  return 'items' in item;
};

export const isFile = (item: FilesystemItem): item is FileItem => {
  return !isFolder(item);
};

export const findItemById = (
  items: FilesystemItem[],
  id: string
): FilesystemItem | undefined => {
  for (const item of items) {
    if (item.id === id) return item;
    if (isFolder(item)) {
      const found = findItemById(item.items, id);
      if (found) return found;
    }
  }
  return undefined;
};

export const findParentFolder = (
  items: FilesystemItem[],
  id: string,
  parent: FolderItem | null = null
): FolderItem | null => {
  for (const item of items) {
    if (item.id === id) return parent;
    if (isFolder(item)) {
      const found = findParentFolder(item.items, id, item);
      if (found) return found;
    }
  }
  return null;
};

export const getItemPath = (
  items: FilesystemItem[],
  id: string
): FilesystemItem[] => {
  const result: FilesystemItem[] = [];
  
  const traverse = (
    currentItems: FilesystemItem[],
    targetId: string,
    path: FilesystemItem[]
  ): boolean => {
    for (const item of currentItems) {
      const newPath = [...path, item];
      
      if (item.id === targetId) {
        result.push(...newPath);
        return true;
      }
      
      if (isFolder(item)) {
        if (traverse(item.items, targetId, newPath)) {
          return true;
        }
      }
    }
    
    return false;
  };
  
  traverse(items, id, []);
  return result;
};