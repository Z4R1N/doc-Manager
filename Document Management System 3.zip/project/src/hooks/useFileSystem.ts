import { useState, useCallback } from 'react';
import { FileItem, FolderItem, FilesystemItem, BreadcrumbItem } from '../types';
import { v4 as uuidv4 } from 'uuid';
import { findItemById, isFolder, getItemPath } from '../utils/fileHelpers';

// Initial data structure for the file system
const initialFileSystem: FolderItem[] = [
  {
    id: 'root',
    name: 'My Documents',
    items: [],
    createdAt: new Date(),
    parentId: null,
  },
];

export const useFileSystem = () => {
  const [items, setItems] = useState<FilesystemItem[]>(initialFileSystem);
  const [selectedItemId, setSelectedItemId] = useState<string | null>('root');
  const [breadcrumbs, setBreadcrumbs] = useState<BreadcrumbItem[]>([
    { id: 'root', name: 'My Documents' },
  ]);

  const selectedItem = selectedItemId
    ? findItemById(items, selectedItemId) || null
    : null;

  // Create a new folder
  const createFolder = useCallback(
    (name: string, parentId: string | null = null) => {
      const newFolder: FolderItem = {
        id: uuidv4(),
        name,
        items: [],
        createdAt: new Date(),
        parentId,
      };

      setItems((prevItems) => {
        // If no parent ID specified, add to root level
        if (!parentId) {
          return [...prevItems, newFolder];
        }

        // Otherwise, find the parent folder and add the new folder to it
        const updateItems = (items: FilesystemItem[]): FilesystemItem[] => {
          return items.map((item) => {
            if (!isFolder(item)) return item;
            if (item.id === parentId) {
              return {
                ...item,
                items: [...item.items, newFolder],
              };
            }
            return {
              ...item,
              items: updateItems(item.items),
            };
          });
        };

        return updateItems(prevItems);
      });

      return newFolder.id;
    },
    []
  );

  // Upload a file
  const uploadFile = useCallback(
    (file: File, parentId: string) => {
      // Check if file is PDF or DOCX
      const fileType = file.name.toLowerCase().endsWith('.pdf') ? 'pdf' : 
                      file.name.toLowerCase().endsWith('.docx') ? 'docx' : null;
                      
      if (!fileType) {
        throw new Error('Only PDF and DOCX files are supported');
      }

      const newFile: FileItem = {
        id: uuidv4(),
        name: file.name,
        type: fileType,
        url: URL.createObjectURL(file),
        createdAt: new Date(),
      };

      setItems((prevItems) => {
        const updateItems = (items: FilesystemItem[]): FilesystemItem[] => {
          return items.map((item) => {
            if (!isFolder(item)) return item;
            if (item.id === parentId) {
              return {
                ...item,
                items: [...item.items, newFile],
              };
            }
            return {
              ...item,
              items: updateItems(item.items),
            };
          });
        };

        return updateItems(prevItems);
      });

      return newFile.id;
    },
    []
  );

  // Select an item and update breadcrumbs
  const selectItem = useCallback(
    (id: string) => {
      setSelectedItemId(id);

      // Update breadcrumbs
      const path = getItemPath(items, id);
      if (path.length > 0) {
        const newBreadcrumbs = path.map((item) => ({
          id: item.id,
          name: item.name,
        }));
        setBreadcrumbs(newBreadcrumbs);
      }
    },
    [items]
  );

  // Handle real file upload
  const handleFileUpload = useCallback(
    (parentId: string) => {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = '.pdf,.docx';
      input.multiple = false;

      input.onchange = (e) => {
        const file = (e.target as HTMLInputElement).files?.[0];
        if (file) {
          try {
            uploadFile(file, parentId);
          } catch (error) {
            alert(error instanceof Error ? error.message : 'Failed to upload file');
          }
        }
      };

      input.click();
    },
    [uploadFile]
  );

  return {
    items,
    selectedItem,
    selectedItemId,
    breadcrumbs,
    createFolder,
    uploadFile,
    selectItem,
    handleFileUpload,
  };
};