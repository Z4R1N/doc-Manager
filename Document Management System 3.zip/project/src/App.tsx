import React, { useState } from 'react';
import Sidebar from './components/Sidebar/Sidebar';
import FileViewer from './components/FileViewer/FileViewer';
import Modal from './components/UI/Modal';
import Button from './components/UI/Button';
import { useFileSystem } from './hooks/useFileSystem';

function App() {
  const {
    items,
    selectedItem,
    selectedItemId,
    breadcrumbs,
    createFolder,
    selectItem,
    handleFileUpload,
  } = useFileSystem();

  const [isCreateFolderModalOpen, setIsCreateFolderModalOpen] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');
  const [currentParentId, setCurrentParentId] = useState<string | null>(null);

  const handleCreateRootFolder = () => {
    setCurrentParentId(null);
    setNewFolderName('');
    setIsCreateFolderModalOpen(true);
  };

  const handleCreateFolder = (parentId: string) => {
    setCurrentParentId(parentId);
    setNewFolderName('');
    setIsCreateFolderModalOpen(true);
  };

  const handleUploadFile = (parentId: string) => {
    handleFileUpload(parentId);
  };

  const handleSubmitCreateFolder = () => {
    if (newFolderName.trim()) {
      const newFolderId = createFolder(newFolderName.trim(), currentParentId);
      setIsCreateFolderModalOpen(false);
      setNewFolderName('');
      selectItem(newFolderId);
    }
  };

  return (
    <div className="flex h-screen w-full overflow-hidden">
      {/* Sidebar */}
      <div className="w-64 flex-shrink-0 overflow-hidden">
        <Sidebar
          items={items}
          selectedItemId={selectedItemId}
          onSelect={selectItem}
          onCreateRootFolder={handleCreateRootFolder}
          onCreateFolder={handleCreateFolder}
          onUploadFile={handleUploadFile}
        />
      </div>

      {/* Main content */}
      <div className="flex-1 overflow-hidden">
        <FileViewer
          selectedItem={selectedItem}
          breadcrumbs={breadcrumbs}
          onBreadcrumbClick={selectItem}
        />
      </div>

      {/* Create folder modal */}
      <Modal
        isOpen={isCreateFolderModalOpen}
        onClose={() => setIsCreateFolderModalOpen(false)}
        title="Create New Folder"
      >
        <div className="space-y-4">
          <div>
            <label
              htmlFor="folderName"
              className="block text-sm font-medium text-gray-700"
            >
              Folder Name
            </label>
            <input
              type="text"
              id="folderName"
              value={newFolderName}
              onChange={(e) => setNewFolderName(e.target.value)}
              className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
              placeholder="Enter folder name"
              autoFocus
            />
          </div>
          <div className="flex justify-end space-x-2">
            <Button
              variant="secondary"
              onClick={() => setIsCreateFolderModalOpen(false)}
            >
              Cancel
            </Button>
            <Button variant="primary" onClick={handleSubmitCreateFolder}>
              Create
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

export default App;